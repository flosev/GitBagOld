package net.flosev.quiz.controller;

public class SessionAttributes {
    public static final String QUIZES_IN_BUCKET = "quizesInBucket";
    public static final String USER = "user";

    private SessionAttributes() {
    }
}
